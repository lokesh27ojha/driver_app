import 'package:driver_app/model/Driver.dart';
import 'package:driver_app/model/DriverState.dart';
import 'package:driver_app/model/RideRequest.dart';

class AppStateService{

  static Driver? currentDriver;
  static RideRequest? currentRide;

  static DriverState driverState= DriverState.OFFLINE;

  static dynamic currentRequest;

  static void setDriver(Driver driver){
    currentDriver=driver;
  }

  static void setState(DriverState state){
    driverState=state;
  }

  static void setRequest(dynamic request){
    currentRequest= request;
  }

  static void clearRequest(){
    currentRequest=null;
  }

  static void clearDriver() {
  currentDriver = null;
}

  static void setRide(RideRequest ride){
    currentRide =ride;
  }
  
  static void clearRide(){
    currentRide=null;
  }

}