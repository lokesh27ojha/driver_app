import 'package:flutter/material.dart';

class DriverDetailsProfileImage extends StatelessWidget {
  const DriverDetailsProfileImage({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: CircleAvatar(
        radius: 60,
        backgroundImage: AssetImage("assets/img/dp.jpg"),
      ),
    );
  }
}