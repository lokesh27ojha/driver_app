import 'package:driver_app/model/DriverState.dart';
import 'package:driver_app/model/RideRequest.dart';
import 'package:driver_app/service/AppStateService.dart';
//import 'package:driver_app/screens/HomeScreen.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
//import 'package:lottie/lottie.dart';
//import 'package:lottie/lottie.dart';

class HomeMapSection extends StatefulWidget {
  final DriverState status;
  final RideRequest? ride;

  const HomeMapSection({
    super.key,
    required this.status,
    required this.ride
  });

  @override
  State<HomeMapSection> createState() => _HomeMapSectionState();
}

class _HomeMapSectionState extends State<HomeMapSection>{

  GoogleMapController? mapController;
  LatLng? currentPos;
  LatLng? pickupLocation;
  Set<Polyline> polylines={};

  final ride=AppStateService.currentRide;

  @override void initState() {
    // TODO: implement initState
    super.initState();
    _startLocationUpdate();
  }

  void _drawRoute(LatLng from, LatLng to){
    polylines.clear();

    polylines.add(
      Polyline(
        polylineId: const PolylineId("route"),
        points: [from, to],
        width: 5
      )
    );

  }

  Future<bool> _handlePermission() async {
  bool serviceEnabled = await Geolocator.isLocationServiceEnabled();

  if (!serviceEnabled) {
    print("❌ Location services OFF");
    return false;
  }

  LocationPermission permission = await Geolocator.checkPermission();

  if (permission == LocationPermission.denied) {
    permission = await Geolocator.requestPermission();
  }

  if (permission == LocationPermission.denied) {
    print("❌ Permission denied");
    return false;
  }

  if (permission == LocationPermission.deniedForever) {
    print("❌ Permission permanently denied");
    return false;
  }

  print("✅ Permission granted");
  return true;
}

  Future<void> _startLocationUpdate() async {

  bool hasPermission = await _handlePermission();
  if (!hasPermission) return;

  Geolocator.getPositionStream(
    locationSettings: const LocationSettings(
      accuracy: LocationAccuracy.high,
      distanceFilter: 10,
    ),
  ).listen((Position position) {

    final newPos = LatLng(position.latitude, position.longitude);

    print("📍 $newPos");

    setState(() {
      currentPos = newPos;
    });

    mapController?.animateCamera(
      CameraUpdate.newLatLng(currentPos!),
    );
  });
}

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    if(widget.status==DriverState.OFFLINE){
      return Center(
        //child: Lottie.asset("assets/gif/internet.json"),
      );
    }

    if(currentPos==null){
      return Center(
        //child: Lottie.asset(""),
      );
    }

    // 🔥 If going to pickup → draw route
    if (widget.status == DriverState.GOING_TO_PICKUP && ride != null) {
      _drawRoute(currentPos!, ride!.pickupLocation);
    }

    return SizedBox.expand(
      child: GoogleMap(
        //key: ValueKey(currentPos),
        initialCameraPosition: CameraPosition(
          target: currentPos!,
          zoom: 14
          ),
          myLocationEnabled: true,
          myLocationButtonEnabled: true,
          onMapCreated: (controller){
            mapController=controller;
          },
          markers: {
            
            Marker(
              markerId: const MarkerId("current"),
              position: currentPos!,
            ),
            if(ride!=null 
                && widget.status ==DriverState.GOING_TO_PICKUP)
                Marker(
                  markerId: const MarkerId("pickup"),
                  //position: ride.pickupLocation,
                  icon : BitmapDescriptor.defaultMarkerWithHue(
                    BitmapDescriptor.hueBlue,
                  )
                ),
          },
          polylines: polylines,
      ),
    );

  }

  

}




  // @override
  // Widget build(BuildContext context) {
  //   if (status == DriverState.OFFLINE) {
  //     return Lottie.asset("assets/gif/internet.json");
  //   }

  //   if (hasActiveTrip) {
  //     return const Center(child: Text("Route Map (Polyline)"));
  //   }

  //   return const Center(child: Text("Live Location Map"));
  // }
