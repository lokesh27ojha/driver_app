import 'package:driver_app/model/Address.dart';

class Driver {

  int? driverId;
  final String firstName;
  final String lastName;
  final String email;
  final String phone;
  final Address address;
  final String password;
  final String licenceNumber;
  String status;


  Driver({
    this.driverId,
    required this.firstName,
    required this.lastName, 
    required this.email,
    required this.phone,
    required this.address,
    required this.password,
    required this.licenceNumber,
    this.status="Available",
    });


}