class
 Address {

  int? addressId;
  final String streetLine1;
  final String streetLine2;
  final String city;
  final String state;
  final String pincode;

  Address({
    this.addressId,
    required this.streetLine1, 
    required this.streetLine2, 
    required this.city, 
    required this.state, 
    required this.pincode
  });

  

}