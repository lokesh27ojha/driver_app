import 'package:google_maps_flutter/google_maps_flutter.dart';

class RideRequest {
  int? rideRequestId;
  final String pickup;
  final LatLng pickupLocation;
  final String drop;
  final LatLng dropLocation;
  final double distance;
  final int eta;
  final double fare;

  RideRequest({
    this.rideRequestId,
    required this.pickup,
    required this.pickupLocation,
    required this.drop,
    required this.dropLocation,
    required this.distance,
    required this.eta,
    required this.fare
  });
}