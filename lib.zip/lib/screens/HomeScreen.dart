//import 'dart:nativewrappers/_internal/vm/lib/ffi_allocation_patch.dart';

//import 'package:driver_app/model/Driver.dart';
import 'package:driver_app/data/MockRideRequestData.dart';
import 'package:driver_app/model/RideRequest.dart';
import 'package:flutter/material.dart';
import 'package:driver_app/components/home/HomeTopBar.dart';
import 'package:driver_app/components/home/HomeTripInfoCard.dart';
import 'package:driver_app/components/home/HomeStatusToggle.dart';
import 'package:driver_app/components/home/HomeMapSection.dart';
import 'package:driver_app/components/home/HomeRequestList.dart';
import 'package:driver_app/service/AppStateService.dart';
import 'package:driver_app/model/DriverState.dart';




class HomeScreen extends StatefulWidget {

  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {

  List<RideRequest> rideRequests=MockRideRequestData.rideRequests;

  DriverState get status => AppStateService.driverState;

  final driver = AppStateService.currentDriver;
  final ride = AppStateService.currentRide;

  

  @override
  Widget build(BuildContext context) {
    if((status==DriverState.GOING_TO_PICKUP || status==DriverState.ON_TRIP)
          && ride==null
    ){
      AppStateService.setState(DriverState.ONLINE);
    }
    return Scaffold(
      body: Column(
        children: [

          HomeTopBar(
            name: driver?.firstName ?? "Driver",
            license: driver?.licenceNumber ?? "N/A",
            imagePath: "assets/img/dp.jpg",
            onProfileTap: () {
              Navigator.of(context).pushNamed("/profile");
            },
          ),

          if(status==DriverState.ON_TRIP)
            const HomeTripInfoCard(),

          HomeStatusToggle(
            status: status,
            isEnabled: status == DriverState.ONLINE || status==DriverState.OFFLINE, // 🔥 key logic
            onToggle: (value) {
              setState(() {
                AppStateService.setState(
                  value ? DriverState.ONLINE : DriverState.OFFLINE,
                );
              });
            },
          ),

          Expanded(
            child: HomeMapSection(
              status: status,
              ride: AppStateService.currentRide,
              //hasActiveTrip: status==DriverState.ON_TRIP,
            ),
          ),

          if (status == DriverState.ONLINE || status == DriverState.REQUEST_RECEIVED)
            HomeRequestList(
              requestList: rideRequests,
              onAccept: (ride) {
                setState(() {
                  AppStateService.setRide(ride);
                  AppStateService.setState(DriverState.GOING_TO_PICKUP);
                });
              },
              onReject: (ride) {},
            ),
        ],
      ),
    );
  }
}