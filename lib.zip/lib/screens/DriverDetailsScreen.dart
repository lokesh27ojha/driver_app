import 'package:driver_app/components/driver_details/DriverDetailsEditableField.dart';
import 'package:driver_app/components/driver_details/DriverDetailsLogOutButton.dart';
import 'package:driver_app/components/driver_details/DriverDetailsProfileImage.dart';
import 'package:driver_app/components/driver_details/DriverDetailsSaveButton.dart';
import 'package:driver_app/service/AppStateService.dart';
import 'package:driver_app/service/SessionService.dart';
import 'package:flutter/material.dart';


class DriverDetailsScreen extends StatefulWidget {
  const DriverDetailsScreen({super.key});

  @override
  State<DriverDetailsScreen> createState() => _DriverDetailsScreenState();
}

class _DriverDetailsScreenState extends State<DriverDetailsScreen> {
  bool isEditing = false;

  final nameController = TextEditingController(text: AppStateService.currentDriver?.firstName);
  final surnameController = TextEditingController(text: AppStateService.currentDriver?.lastName);
  final phoneController = TextEditingController(text: AppStateService.currentDriver?.phone);
  final licenseController = TextEditingController(text: AppStateService.currentDriver?.licenceNumber);

  final sessionService = SessionService();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Driver Details"),
        actions: [
          IconButton(
            icon: Icon(isEditing ? Icons.close : Icons.edit),
            onPressed: () {
              setState(() {
                isEditing = !isEditing;
              });
            },
          )
        ],
      ),

      body: SingleChildScrollView(
        child: Column(
          children: [

            const SizedBox(height: 20),

            // 🔹 Profile Image
            const DriverDetailsProfileImage(),

            const SizedBox(height: 20),

            // 🔹 Fields
            DriverDetailsEditableField(
              label: "Name",
              controller: nameController,
              isEditing: isEditing,
            ),

            DriverDetailsEditableField(
              label: "Surname",
              controller: surnameController,
              isEditing: isEditing,
            ),

            DriverDetailsEditableField(
              label: "Phone",
              controller: phoneController,
              isEditing: false, // 🔴 always locked
            ),

            DriverDetailsEditableField(
              label: "License",
              controller: licenseController,
              isEditing: isEditing,
            ),

            const SizedBox(height: 20),

            // 🔹 Save Button
            if (isEditing)
              DriverDetailsSaveButton(
                onSave: () {
                  setState(() {
                    isEditing = false;
                  });
                },
              ),
            
            // logoutbutton

            const SizedBox(height: 10),

            const DriverDetailsLogOutButton(),

          ],
        ),
      ),
    );
  }
}