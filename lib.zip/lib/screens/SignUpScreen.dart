import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:image_cropper/image_cropper.dart';

import 'package:driver_app/components/signup/SignUpBackground.dart';
import 'package:driver_app/components/signup/SignUpHeader.dart';
import 'package:driver_app/components/signup/ProfileImagePicker.dart';
import 'package:driver_app/components/signup/SignUpTextField.dart';
import 'package:driver_app/components/signup/SignupButtonRow.dart';


class SignUpScreen extends StatefulWidget {
  const SignUpScreen({super.key});

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {

  File? _profileImage;

  Future<void> pickAndCropImage() async {
    final picker = ImagePicker();

    final pickedFile = await picker.pickImage(
      source: ImageSource.gallery,
    );

    if (pickedFile == null) return;

    final croppedFile = await ImageCropper().cropImage(
      sourcePath: pickedFile.path,
      aspectRatio: const CropAspectRatio(ratioX: 1, ratioY: 1),
    );

    if (croppedFile != null) {
      setState(() {
        _profileImage = File(croppedFile.path);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return SignUpBackground(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: Stack(
          children: [
            const SignUpHeader(),

            SingleChildScrollView(
              child: Container(
                padding: EdgeInsets.fromLTRB(
                  40,
                  MediaQuery.of(context).size.height * 0.35,
                  40,
                  0,
                ),
                child: Column(
                  children: [

                    ProfileImagePicker(
                      imageFile: _profileImage,
                      onEdit: pickAndCropImage,
                    ),

                    const SizedBox(height: 20),

                    const SignUpTextField(hint: "Name"),
                    const SizedBox(height: 15),

                    const SignUpTextField(hint: "Email"),
                    const SizedBox(height: 15),

                    const SignUpTextField(hint: "Phone"),
                    const SizedBox(height: 15),

                    const SignUpTextField(
                      hint: "Password",
                      isPassword: true,
                    ),
                    const SizedBox(height: 15),

                    const SignUpTextField(hint: "Licence Number"),
                    const SizedBox(height: 15),

                    SignUpButtonRow(
                      onPressed: () {
                        Navigator.pushNamed(context, "/profile");
                      },
                    ),

                    const SizedBox(height: 25),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}