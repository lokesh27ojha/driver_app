import 'package:driver_app/model/RideRequest.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class MockRideRequestData {
  
  static List<RideRequest> rideRequests =[

    RideRequest(pickup: "port A", pickupLocation: LatLng(28.085531, 77.577649), drop: "california",dropLocation: LatLng(28.720921, 77.780896), distance: 150, eta: 200, fare: 100),
    RideRequest(pickup: "port B", pickupLocation: LatLng(28.409742, 77.830334), drop: "new jersey", dropLocation: LatLng(28.937477, 77.237073), distance: 120, eta: 150, fare: 80),

  ];

}